# Plano de Clonagem e Localização (Portugal)

Este plano descreve a reestruturação completa do projeto para clonar a estrutura do site original, adaptando-a para o mercado português com pagamentos via MB Way e moeda em Euro.

## Alterações Visuais e Estruturais

- **Clonagem de Estrutura**: Replicar exatamente o cabeçalho, hero, cartões de benefícios e sistema de notificações do site original.
- **Identidade Visual**: Manter o tema "TikTok Rewards" com a cor Coral (#ff4d67) e as animações de "Live".
- **Localização PT-PT**:
    - Traduzir todos os textos para Português de Portugal (ex: "utilizadores", "registo", "levantamento").
    - Converter todos os valores monetários para Euro (€).
    - Substituir referências a "Pix" por "MB Way".

## Componentes e Páginas

- **Página Inicial (`/`)**:
    - Cabeçalho com selo de "Parceiro Oficial".
    - Contador de vagas dinâmico e barra de progresso.
    - Seção de benefícios com ícones e textos localizados.
    - Fluxo de Quiz multi-etapa integrado na página ou via navegação.
- **Página de Levantamento (`/withdraw`)**:
    - Interface dedicada para levantamento via MB Way.
    - Campo de entrada para número de telemóvel (formato português).
    - Simulação de processamento seguro.

## Detalhes Técnicos

- **Estilos**: Atualizar `src/styles.css` com as classes utilitárias exatas do clone.
- **Navegação**: Usar TanStack Router para transições entre o quiz e a página de levantamento.
- **Simulação**: O sistema de notificações e o processamento de levantamento serão simulados para garantir a experiência do utilizador sem necessidade de backend real imediato.

## Próximos Passos

1. Atualizar `src/styles.css` com o CSS base do clone.
2. Refatorar `src/routes/index.tsx` para a nova estrutura.
3. Atualizar `src/routes/withdraw.tsx` com a interface MB Way final.
4. Validar o fluxo completo no preview.
