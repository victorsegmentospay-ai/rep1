# Plano de Clonagem do Quiz TikTok

O objetivo é clonar a estrutura visual e funcional da landing page do quiz do TikTok para o projeto atual, utilizando TanStack Start.

## Alterações Visuais e de UI

- **Metadados e SEO**: Configurar títulos, descrições e imagens OpenGraph idênticos aos da página original para manter a aparência ao compartilhar.
- **Estilização**: Implementar o sistema de cores (tokens CSS) e estilos globais extraídos do projeto original no `src/styles.css`.
- **Componentes**:
  - `LiveBar`: Barra superior com animação de "Ao Vivo".
  - `Header`: Logotipo e selo de verificado.
  - `Hero`: Título principal e contador de usuários online.
  - `Cards`: Seção de vagas e benefícios.
  - `CTA`: Botão de chamada para ação com animação.
  - `Notificações`: Sistema de pop-ups simulando novos ganhadores.

## Detalhes Técnicos

- **Roteamento**: Criar a rota principal em `src/routes/index.tsx` que renderiza a landing page.
- **Interatividade**:
  - Animações CSS para o preenchimento da barra de progresso e notificações.
  - Lógica React para exibir notificações aleatórias em intervalos de tempo.
- **Assets**: Utilizar os SVGs e imagens inline (base64) conforme extraídos da página original para garantir que nada quebre por falta de arquivos externos.

## Próximos Passos

1. Atualizar `src/styles.css` com as variáveis e estilos base.
2. Refatorar `src/routes/index.tsx` para incluir a estrutura HTML/JSX clonada.
3. Adicionar lógica de interatividade (notificações) na página principal.